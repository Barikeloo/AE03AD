package vista;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;

public class Joc extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	public JButton btnComenzarJuego;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Joc frame = new Joc();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Joc() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 706, 343);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		btnComenzarJuego = new JButton("Començar Joc");
		btnComenzarJuego.setBounds(10, 11, 143, 23);
		contentPane.add(btnComenzarJuego);
		
		JButton btnGuardarDatos = new JButton("Guardar Datos");
		btnGuardarDatos.setBounds(10, 45, 143, 23);
		contentPane.add(btnGuardarDatos);
		
		JLabel lblTiempo = new JLabel("00:00");
		lblTiempo.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblTiempo.setBounds(58, 142, 48, 73);
		contentPane.add(lblTiempo);
		
		JButton btnVerResultados = new JButton("Ver Resultados");
		btnVerResultados.setBounds(10, 79, 143, 23);
		contentPane.add(btnVerResultados);
		
		JButton btnTerminarJuego = new JButton("Terminar Juego");
		btnTerminarJuego.setBounds(10, 113, 143, 23);
		contentPane.add(btnTerminarJuego);
	}
	
	
}
