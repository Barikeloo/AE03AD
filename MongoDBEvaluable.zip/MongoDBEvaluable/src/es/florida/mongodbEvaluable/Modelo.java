package es.florida.mongodbEvaluable;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.List;


import javax.imageio.ImageIO;
import org.bson.Document;

import org.json.JSONObject;

import com.mongodb.Cursor;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;

import java.io.ByteArrayInputStream;
import java.util.Base64;
public class Modelo {

    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> usuarisCollection;
    private MongoCollection<Document> imagesCollection;
    private MongoCollection<Document> recordsCollection;

    public void mostrarIdsDeImagenes() {
    // Obtener todos los documentos de la colección "imagesCollection"
    FindIterable<Document> iterable = imagesCollection.find();

    // Obtener un cursor para iterar sobre los documentos
    MongoCursor<Document> cursor = iterable.iterator();

    // Iterar sobre los documentos y mostrar los IDs de las imágenes
    while (cursor.hasNext()) {
        Document document = cursor.next();
        String idImagen = document.getString("id");
        System.out.println("ID de la Imagen: " + idImagen);
    }
}

    public boolean connectToDatabase(String jsonFilePath) {
        try {
            // Lee el contenido del archivo JSON
            String jsonString = new String(Files.readAllBytes(Paths.get(jsonFilePath)), StandardCharsets.UTF_8);
            System.out.println("Contenido del JSON: " + jsonString);

            // Convierte el JSON a un objeto JSONObject
            JSONObject json = new JSONObject(jsonString);

            // Obtiene los valores del JSON
            String ip = json.getString("ip");
            int port = json.getInt("port");
            String dbName = json.getString("bd");

            // Establece la conexión a MongoDB
            mongoClient = new MongoClient(ip, port);
            database = mongoClient.getDatabase(dbName);

            // Asigna las colecciones
            usuarisCollection = database.getCollection("usuaris");
            imagesCollection = database.getCollection("imatges");
            recordsCollection = database.getCollection("records");

            System.out.println("Accedemos a la base de datos jijiji");

            // Puedes imprimir las colecciones si lo deseas
            System.out.println("Colección de usuaris: " + usuarisCollection);
            System.out.println("Colección de images: " + imagesCollection);
            System.out.println("Colección de records: " + recordsCollection);

            return true;
        } catch (IOException e) {
            e.printStackTrace();
            // Manejar la excepción según tus necesidades
            return false; // O lanzar otra excepción, según tus necesidades
        }
    }

    public void cargarImagenes() {
        MongoCursor<Document> cursor = imagesCollection.find().iterator();
        while (cursor.hasNext()) {
        	System.out.println("Encuentro imagen");
            Document document = cursor.next();
            String base64String = document.getString("base64");
            byte[] btDataFile = Base64.getDecoder().decode(base64String);
            
            try (FileOutputStream fos = new FileOutputStream("./src/img/" + document.getString("id"))) {
                fos.write(btDataFile);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    public boolean ComprobarUsuario(String usuario, String contrasena) {
    try {
        // Aplica SHA-256 al hash de la contraseña proporcionada
        String hashedPassword = hashSHA256(contrasena);

        // Comprueba si existe un documento con el usuario dado y el hash de la contraseña dada en la colección "usuaris"
        long count = usuarisCollection.countDocuments(
                Filters.and(
                        Filters.eq("user", usuario),
                        Filters.eq("pass", hashedPassword)
                )
        );

        return count > 0; // Retorna true si el usuario y la contraseña coinciden, false en caso contrario
    } catch (Exception e) {
        e.printStackTrace();
        // Manejar la excepción según tus necesidades
        return false; // Retornar false en caso de error
    }
}

private String hashSHA256(String contrasena) {
    try {
        // Aplica SHA-256 al hash de la contraseña
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hashedBytes = digest.digest(contrasena.getBytes());

        // Convierte el hash a formato hexadecimal
        StringBuilder hexString = new StringBuilder();
        for (byte hashedByte : hashedBytes) {
            String hex = Integer.toHexString(0xff & hashedByte);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }

        return hexString.toString();
    } catch (Exception e) {
        e.printStackTrace();
        // Manejar la excepción según tus necesidades
        return null; // Retornar null en caso de error
    }
}

}
