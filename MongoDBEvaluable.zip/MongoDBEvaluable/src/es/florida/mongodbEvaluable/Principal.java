package es.florida.mongodbEvaluable;

import java.io.IOException;

import vista.Joc;
import vista.Login;
import vista.Puntuacions;

public class Principal {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Login login = new Login();
		Joc joc = new Joc();
		Modelo model = new Modelo();
		Puntuacions puntuacions = new Puntuacions();
		Controlador controlador = new Controlador(model, login, joc, puntuacions);
		
		login.setVisible(true);
	}

}
