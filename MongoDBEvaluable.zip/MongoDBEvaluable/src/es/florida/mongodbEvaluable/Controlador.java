package es.florida.mongodbEvaluable;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.IOException;

import javax.swing.JOptionPane;

import vista.Joc;
import vista.Login;
import vista.Puntuacions;

public class Controlador {

	private Modelo model;
	private Login login;
	private Joc joc;
	private Puntuacions puntuacions;

	public Controlador(Modelo model, Login login, Joc joc, Puntuacions puntuacions) throws IOException {
		this.model = model;
		this.login = login;
		this.joc = joc;
		this.puntuacions = puntuacions;
		model.connectToDatabase("./JsonConexion.json");
		model.mostrarIdsDeImagenes();
		initEventHandlers();
	}

	// this.actionListenerConectat = new ActionListener() {

	// @Override
	// public void actionPerformed(ActionEvent e) {
	// }
	// }

	public void initEventHandlers() {
		login.btnAcceder.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				model.mostrarIdsDeImagenes();
				String usuario = login.txtUser.getText();
				String Password = login.txtContraseña.getText();
				boolean loggedIn = model.ComprobarUsuario(usuario, Password);
				if (loggedIn) {
					JOptionPane.showMessageDialog(null, "Inicio de sesión exitoso");
					model.cargarImagenes();
					login.setVisible(false);
					joc.setVisible(true);
				} else {
					JOptionPane.showMessageDialog(null, "Nombre de usuario o Password incorrectos");
					login.txtUser.setText("");
					login.txtContraseña.setText("");
				}
			}
		});


		login.checkBoxCrearCuenta.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
            	if (login.checkBoxCrearCuenta.isSelected()) {
                    login.mostrarRestoComponentes(true);
                    login.btnAcceder.setVisible(false);
                } else {
                	login.mostrarRestoComponentes(false);
                }
            }
        });
		
		joc.btnComenzarJuego.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
	}
}